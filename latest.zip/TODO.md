# OS
* write detailed readme with config and secrets examples

# networking
https://developers.google.com/apis-explorer/#p/compute/v1/
