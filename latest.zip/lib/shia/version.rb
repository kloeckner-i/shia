module Shia
  VERSION = '0.1.5.0'.freeze
end
