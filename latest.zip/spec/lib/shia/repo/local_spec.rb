require 'spec_helper'

module Shia
  module Repo
    describe Local do
    end
  end
end
