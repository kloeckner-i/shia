require 'spec_helper'

module Shia
  describe Ranch do
  end
end
