require 'spec_helper'

module Shia
  module Ranch
    describe EnvironmentManager do
    end
  end
end
