require 'spec_helper'

module Shia
  module Ranch
    describe StackManager do
      let(:stack_manager) { StackManager.new(options: OpenStruct.new) }
    end
  end
end
